var cl = console.log



const showModalBtn = document.getElementById('showModalBtn');
const backDrop = document.getElementById('backDrop');
const movieModal = document.getElementById('movieModal');
const closeModals = [...document.querySelectorAll('.closeModal')];
const movieForm = document.getElementById('movieForm');
const movieTitleControl = document.getElementById('movieTitle');
const imgUrlControl = document.getElementById('imgUrl');
const overviewControl = document.getElementById('overview');
const ratingControl = document.getElementById('rating');
const movieContainer = document.getElementById('movieContainer');


let moviesArr = [
	{
		movieTitle: "start up",
		imgUrl: 
		"https://s.yimg.com/fz/api/res/1.2/So8lzCa1Dwt4PeBCIrBy8w--~C/YXBwaWQ9c3JjaGRkO2ZpPWZpdDtoPTI2MDtxPTgwO3c9MTk0/https://s.yimg.com/zb/imgv1/f0136b11-8899-3fb6-9762-49bdd4cf650a/t_500x300",
		rating: "4",
		overview: " Seo Dal Mi has dreams of becoming Korea's own Steve Jobs, and with her genius first love, an investor, and a business insider by her side, her dream may be closer than she thinks.",
		movieId: "fe9b8255-6c78-4f1e-abbf-446a9cece238"
	}
]


const templtingOfMovieCards = (arr) => {
	let result = '';

	arr.forEach(movie => {
		result += `
		        <div class="col-md-3">	
					<div class="card">
						<figure class="moviecard">
							<img src="${movie.imgUrl}" 
							alt="${movie.movieTitle}" 
							title="${movie.movieTitle}">
							<figcaption>
								<div class="titleInfo p-4">
									<div class="row">
										<div class="col-10">
											<h4>
											${movie.movieTitle}
											</h4>
										<div class="col-2">
											<span class="rating">
											${movie.rating}
											</span>
										</div>
										</div>
									</div>
								</div>
								<div class="overview p-4">
									<h5>overview</h5>
									<p>${movie.overview}</p>
								</div>
							</figcaption>
						</figure>
					</div>
		         </div>
		          `
	})

	movieContainer.innerHTML = result;
}

templtingOfMovieCards(moviesArr)

//teampltingOfMovieCards



const random_uuid = uuidv4();

// Print the UUID
console.log(random_uuid);

function uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'
    .replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0, 
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}




const movieModalHandler = () => {
	backDrop.classList.toggle('active')
	movieModal.classList.toggle('active')
}


const onMovieAdd = (eve) => {
	eve.preventDefault();
	//we will get a new movie object
    let newMovieObj = {
		movieTitle : movieTitleControl.value,
		imgUrl : imgUrlControl.value,
		rating : ratingControl.value,
		overview : overviewControl.value,
		movieId : random_uuid,
	}

	cl(newMovieObj)


	// send this new movie data to DB

	moviesArr.push(newMovieObj)
	//we will show this movie obj on UI (card)
    templtingOfMovieCards(moviesArr)
	//form reset
    movieForm.reset();
	//hide modal and backDrop
	movieModalHandler();

}


showModalBtn.addEventListener('click', movieModalHandler);
closeModals.forEach(ele => {
	ele.addEventListener("click", movieModalHandler)
});

movieForm.addEventListener("submit", onMovieAdd)